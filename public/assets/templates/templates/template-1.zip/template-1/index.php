<?php
	const BASE = "";
	require_once( 'header.php');
?>	<div class="container-fluid p-1 bg-dark"></div>

		<section class="container-fluid pt-3 pb-5 bg-info">
		<h2 class="text-light mb-4">Te recomendamos</h2>
		<div class="container">
			<div class="row">
				<?php foreach ($api->getLastPosts(2) as $post): ?>
					<div class="col-12 col-md-6 p-2 feature-post-box">
						<div class="card" style="">
						  <div class="card-img-box card-img-top">
						 	<img src="<?= $api->getBaseUrl() . '/assets/img/posts/' . $post->image  ?>" class=" img-card" alt="...">				  	
						  </div>

						  <div class="card-body">
						    <h2 class="card-title"><?= substr($post->title, 0, 55) ?>...</h2>
						    <p class="card-text"><?= $post->description ?></p>
						    <a href="post/<?= $post->slug ?>" class="btn btn-info">Leer Completo</a>
						  </div>
						</div>				
					</div>	

				<?php endforeach; ?>
			</div>

		</div>
		</section>
		<section class="container-fluid  bg-light pt-5 pb-5 ">
		<div class="container">
			
			<section class="row"> 
				<div class="col-12 col-md-6 mt-4 ">
					<div class="container-fluid p-1 bg-dark"></div>

					<div class=" bg-info text-light p-3 related-home">
						<h4>Últimos posts</h4>
						<ul class="list-unstyled pl-3">
							<?php foreach ($api->getLastPosts($post_number) as $post): ?>
								<li><a class="text-light" href="post/<?= $post->slug ?>"><?= $post->title ?></a></li>
							<?php endforeach; ?>						
						</ul>
					</div>					
				</div>

				<div class="col-12 col-md-6 mt-4 ">
					<div class="container-fluid p-1 bg-dark"></div>

					<div class=" bg-info text-light p-3 related-home">
						<h4>Categorías</h4>
						<ul class="list-unstyled pl-3">
							<?php foreach ($api->getCategories() as $category): ?>
								<li><a class="text-light" href="category/<?=$category->slug?>"><?= $category->name ?></a></li>
							<?php endforeach; ?>						
						</ul>
					</div>					
				</div>


			</section>

		</div>
		</section>


	<?php 	require_once('footer.php'); ?>