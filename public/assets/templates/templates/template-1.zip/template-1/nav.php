<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="collapse navbar-collapse" id="">
    <div class="navbar-nav">
		<a class="nav-item nav-link" href="<?= BASE ?>index.php">Inicio</a>

		<?php foreach ($api->getCategories() as $category): ?>

			<a class="nav-item nav-link" href="<?= BASE ?>category/<?=$category->slug?>"><?=$category->name?></a>


		<?php endforeach; ?>

    </div>
  </div>
</nav>	