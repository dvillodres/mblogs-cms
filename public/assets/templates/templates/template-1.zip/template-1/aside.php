<aside class="col-12 col-md-3 p-5">

	<?php if($aside_banner): ?>	
		<div class="pb-3">
			<a href="$aside_banner_link">
				<img class="img-fluid" src="<?= BASE ?>img/<?=$aside_banner_image?>" alt="">
			</a>
		</div>
	<?php endif; ?>


	<h4>Posts Relacionados</h4>
	<ul class="list-unstyled pl-2">
		<?php for ($i=0; $i < $post_numbers_aside; $i++):?>
			<?php if ( isset( $api->getPostsByCategory( $post->categorySlug )[$i] ) && $api->getPostsByCategory( $post->categorySlug )[$i]->id != $post->id): ?>
				<li><a href=""><?= $api->getPostsByCategory( $post->categorySlug )[$i]->title ?></a></li>
			<?php endif ?>
		<?php endfor; ?>
	</ul>

</aside>


