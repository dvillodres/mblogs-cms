<?php
	header("HTTP/1.1 404 Not Found");
	const BASE = "../";
	require_once( 'header.php');
	$post = $api->getPostBySlug($_GET['slug']);
?>


	<div class="row pt-5 pb-5">
		<div class="container text-center">
			<h1>404 - Página no encontrada</h1>
		</div>
	</div>
	<section class="container-fluid pt-3 pb-5 bg-info">
		<h2 class="text-light mb-4">Te recomendamos</h2>
		<div class="container">
			<div class="row">
				<?php foreach ($api->getLastPosts(3) as $post): ?>
					<div class="col-12 col-md-4 p-2 feature-post-box">
						<div class="card" style="">
						  <div class="card-img-box card-img-top">
						 	<img src="<?= $api->getBaseUrl() . '/assets/img/posts/' . $post->image  ?>" class=" img-card" alt="...">				  	
						  </div>

						  <div class="card-body">
						    <h2 class="card-title"><?= substr($post->title, 0, 55) ?>...</h2>
						    <p class="card-text"><?= $post->description ?></p>
						    <a href="post/<?= $post->slug ?>" class="btn btn-info">Leer Completo</a>
						  </div>
						</div>				
					</div>	

				<?php endforeach; ?>
			</div>

		</div>
	</section>		

	<?php 	require_once('footer.php'); ?>