
		<footer class="container-fluid bg-dark text-light text-center
		p-3">
			<p>Sitio web desarrollado a partir de <span class="font-weight-bold ">CMSBlogs</span></p>

		</footer>


	</body>
</html>