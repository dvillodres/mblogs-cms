<?php
	const BASE = "../";
	require_once( 'header.php');
?>


		<section class="container-fluid pt-3 pb-5 bg-info">
		<div class="container">
			<div class="row post-list">
				<?php foreach ($api->getPostsByCategory($_GET['slug']) as $post): ?>
					<div class="col-12 col-md-4 p-2 feature-post-box">
						<div class="card" style="">
						  <div class="card-img-box card-img-top">
						 	<img src="<?= $api->getBaseUrl() . '/assets/img/posts/' . $post->image  ?>" class=" img-card" alt="...">				  	
						  </div>

						  <div class="card-body ">
						    <h2 class="card-title col-12"><?= substr($post->title , 0, 55) ?>...</h2>
						    <p class="card-text col-12"><?= $post->description ?></p>
						    <a href="../post/<?= $post->slug ?>" class="btn btn-info  col-12">Leer Completo</a>
						  </div>
						</div>				
					</div>	

				<?php endforeach; ?>
			</div>		
		</div>
	</section>		

	<?php 	require_once('footer.php'); ?>