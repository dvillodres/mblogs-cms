<?php
/**
 * 
 */
class ApiConsumer{
	
    // Url del servidor donde está instalado "MBlogs CMS"

	private $baseUrl;

    // Apiket asignada al sitio que queremos crear
	private $apiKey;

    // Constructor

	function __construct($baseUrl, $apiKey){
		$this->baseUrl = $baseUrl;
		$this->apiKey = $apiKey;
	}

    // Devuelve un array con los datos básicos del sitio
	public function getSiteData(){

		$data = file_get_contents($this->baseUrl . "/API/" . $this->apiKey, true);
		$data = json_decode($data);

		return $data->data;
	
	} 

    // Devuelve un array con todas las categorías del sitio
	public function getCategories(){

		$data = file_get_contents($this->baseUrl . "/API/" . $this->apiKey . "/categories", true);
		$data = json_decode($data);

		return $data->data;
	
	} 


    // Devuelve un rray con la informacíon relativa a una categoría en base a su slug
    public function getCategoryBySlug($slug){

        $data = file_get_contents($this->baseUrl . "/API/" . $this->apiKey . "/category/$slug", true);
        $data = json_decode($data);

        return $data->data;
    
    } 
    
    // Devuelve un array con los últimos n posts, por defecto 1
    public function getLastPosts($quantity = 1){

        $data = file_get_contents($this->baseUrl . "/API/" . $this->apiKey . "/lasts-posts/$quantity", true);
        $data = json_decode($data);

        return $data->data;
    } 

    // Devuelve los posts pertenecientes a una categoría en base al slug de esta
    public function getPostsByCategory($slug){

        $data = file_get_contents($this->baseUrl . "/API/" . $this->apiKey . "/posts/$slug", true);
        $data = json_decode($data);

        return $data->data;
    
    } 

    // Devuelve toda la información de un post en base a su slug
    public function getPostBySlug($slug){

        $data = file_get_contents($this->baseUrl . "/API/" . $this->apiKey . "/post/$slug", true);
        $data = json_decode($data);

        return $data->data[0];
    
    } 

    
    /**
     * @return mixed
     */
    public function getBaseUrl()
    {
        return $this->baseUrl;
    }

    /**
     * @param mixed $baseUrl
     *
     * @return self
     */
    public function setBaseUrl($baseUrl)
    {
        $this->baseUrl = $baseUrl;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getApiKey()
    {
        return $this->apiKey;
    }

    /**
     * @param mixed $apiKey
     *
     * @return self
     */
    public function setApiKey($apiKey)
    {
        $this->apiKey = $apiKey;

        return $this;
    }
}