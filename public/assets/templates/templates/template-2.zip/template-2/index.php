<?php
	const BASE = "";
	require_once( 'header.php');
?>

<section class="container-fluid pt-0 pb-5">

	<div class="row">
		<?php foreach ($api->getLastPosts($post_number) as $post):  ?>
				<div style="background-image: url(<?= $api->getBaseUrl() . '/assets/img/posts/' . $post->image  ?>) "  class="col-12 col-md-4 feature-posts p-0">
					<a href="post/<?= $post->slug ?>">
						<h2 class="text-light feature-post-title"><?= $post->title ?></h2>
					</a>
				</div>
		<?php endforeach; ?>
	</div>

</section>

<section class="container p-4">
	<div class="row justify-content-center">

		<?php for ($i=0; $i < $categories_number; $i++): 
			$categories = $api->getCategories();
			$category = $categories[$i] ?>
		<div class="col-12 col-lg-4">
			
			<div class="card text-white bg-dark mb-3 p-2">
			  <div class="card-header"><?= $category->name ?></div>
			  <div class="card-body">
			    <p class="card-text text-justify"><?= substr($category->metaDescription, 0, 50) ?>...</p>
			  </div>
			  <a href="<?= BASE ?>category/<?=$category->slug?>" type="button" class="btn btn-outline-light offset-7 col-5">Ver Posts</a>
			</div>

		</div>	

		<?php endfor; ?>

		
	</div>
</section>

	<?php 	require_once('footer.php'); ?>