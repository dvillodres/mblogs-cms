<?php

	// Estos datos los encontrarás en el panel de administración de MBlogs CMS
	
		$apikey = "";
		$host = '';

	// Logo

		$logo = "logo.png";

	// Número de posts en Ultimos post de la portada
		$post_number = 3;

	// Número de posts en Ultimos post de la portada
		$categories_number = 3;

	// Número des posts en la barra lateral de los posts
		$post_numbers_aside = 3;

	// Activar/desactivar imagen y link del banner en la barra lateral
		
		$aside_banner = false;
		$aside_banner_image = "banner.jpg";
		$aside_banner_link = "https://google.com";

	/* Tema elegido
		theme-1 -> Azul Oscuro/ Blanco
		theme-2 -> Morado / Blanco
		theme-3 -> Azul / Blanco
		theme-4 -> Celeste / Rosa Palo
		theme-5 -> Celeste / Blanco
		theme-6 -> Turquesa / Burdeo
		theme-7 -> Celeste / Gris
	*/

		$theme = "theme-4";