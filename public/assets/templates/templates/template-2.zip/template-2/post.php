<?php
	const BASE = "../";
	require_once( 'header.php');
	$post = $api->getPostBySlug($_GET['slug']);
?>


	<div class="row">
		<div class="col-12 col-md-9">
			<div class="container p-5 ">
				<div class="row justify-content-center mb-5">
					<h1 class="col-12"><?= $post->title ?></h1>
					<img style="" class="img-fluid col-8 col-md-4 mt-3" src="<?= $api->getBaseUrl() . "/assets/img/posts/" . $post->image ?>" alt="">
				</div>
				
				<div id="content">
					<?= html_entity_decode($post->content)  ?>
				</div>
			</div>			
		</div>
	
		<?php include 'aside.php'; ?>
	</div>
		

	<?php 	require_once('footer.php'); ?>