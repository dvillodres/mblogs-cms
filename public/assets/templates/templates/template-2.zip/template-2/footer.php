
		<footer class="container-fluid bg-dark text-light text-center
		p-3">
			<p>Sitio web desarrollado a partir de <span class="font-weight-bold ">CMSBlogs</span></p>
			<div class="container">
				<div class="row">
					<div class="col-12 text-left col-md-4">
						<h4>Categorías</h4>
							<ul class="text-left list-unstyled">
						<?php
							for ($i=0; $i < 3; $i++) { 
								$categories = $api->getCategories();
								$category = $categories[$i] ?>
								<li ><a href="category/<?= $category->slug ?>" class="text-white" ><?= $category->name ?></a></li>
							<?php } ?>
						</ul>
					</div>
				</div>
			</div>
		</footer>


	</body>
</html>