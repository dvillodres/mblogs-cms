<?php
	const BASE = "../";
	require_once( 'header.php');
?>


		<section class="container-fluid pt-3 pb-5">
		<div class="container">
			<div class="row ">
				<?php foreach ($api->getPostsByCategory($_GET['slug']) as $post): ?>
					<div class="col-12 col-md-4 mb-2 p-3 bg-white rounded">
						<div class="row justify-content-center">

							<div class="card col-10">
								<div style="height: 160px; overflow: hidden" class="img-box">
									<img src="<?= $api->getBaseUrl() . '/assets/img/posts/' . $post->image  ?>" alt="" class="card-img-top">
								</div>
								<div class="card-body text-primary ">
									<h5 class="card-title"><?= $post->title ?></h5>
									<p class="card-text text-justify"><?= substr($post->content, 0, 120) ?>...</p>
									<div class="clearfix"></div>
									<a href="../post/<?= $post->slug ?>" class="btn btn-dark mt-2">Leer Post</a>
								</div>
							</div>

						</div>
					</div>	

				<?php endforeach; ?>
			</div>		
		</div>
	</section>		

	<?php 	require_once('footer.php'); ?>